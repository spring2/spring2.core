using System;

namespace Spring2.Core.BusinessEntity {

    public interface IBusinessEntity {
	Boolean IsNew {
	    get;
	}
    }
}
