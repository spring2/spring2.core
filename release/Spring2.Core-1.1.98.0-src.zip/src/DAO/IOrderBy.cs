using System;

namespace Spring2.Core.DAO {
    public interface IOrderBy {
	String FormatSql();
    }
}
